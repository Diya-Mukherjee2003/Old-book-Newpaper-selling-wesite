import express from "express";
import { addProduct,updateProduct,deleteProduct} from "../Mvc-controller/ProductController.js";
import { isAuthenticated } from "../middleware/auth.js";

const Router=express.Router();
Router.get('/',(req,res)=>{
    res.json({
        success:true,
        message:'Our_old_newspaper_selling_website'
    })
})
Router.post('/add',isAuthenticated,addProduct)
Router.put('/:id',isAuthenticated,updateProduct)
Router.delete('/:id',isAuthenticated,deleteProduct)

export default Router;