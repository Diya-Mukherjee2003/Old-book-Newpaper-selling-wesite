import mongoose from "mongoose";
const  OrderSchema=new mongoose.Schema({
    buyer_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },
    seller_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },
    product_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Product",
        required:true
    },
    status:{
        type:String,
        enum:['pending','cancelled','completed'],
        default:'pending'
    },
    createdAt:{
        type:Date,
        default:Date.now
    }
})
export const Order=mongoose.model("Order",OrderSchema)