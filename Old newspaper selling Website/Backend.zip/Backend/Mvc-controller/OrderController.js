import { Order} from "../Model/orderModel.js";
import { Product } from "../Model/productModel.js";

export const placeOrder=async(req,res)=>{
    try{
        const {product_id}=req.body
        const buyer_id=req.user.id

        const product = await Product.findById(product_id)
        if(!product){
            return res.status(404).json({
                success:false, 
                message: "Product not found" 
            })
        }
        const newOrder = new Order({
            buyer_id,product_id,seller_id: product.seller_id,status:"pending"
        })
        await newOrder.save()
        res.status(200).json({
            success:true,
            message:'Order placed successfully'
        })
    }catch(error){
        res.status(500).json({ message: "Internal Server error", error });
    }
}

export const getBuyerOrder=async(req,res)=>{
    try{
        const buyer_id=req.user.id
        const orders=await Order.find({buyer_id}).populate("product_id");
        res.json(orders);
    }catch(error){
        res.status(500).json({ message: "Internal Server error", error });
    }
}

export const getSellerOrder=async(req,res)=>{
    try{
        const seller_id=req.user.id
        const orders=await Order.find({seller_id}).populate("product_id");
        res.json(orders);
    }catch(error){
        res.status(500).json({ message: "Internal Server error", error });
    }
}

export const updateOrderStatus=async(req,res)=>{
    try{
        const seller_id=req.user.id
        const { id } = req.params; // Order ID
        const { status } = req.body; // New status
        const order = await Order.findById(id);
        if (!order) {
            return res.status(404).json({ 
                success:false,
                message: "Order not found" 
            });
        }
        if(order.seller_id.toString()!==seller_id){
            return res.status(403).json({
                success:false,
                message:"Unauthorized to update order"
            })
        }
        order.status = status;
        await order.save();
        res.json({ message: "Order status updated", order });
        }
        catch(error){
            res.status(500).json({ message: "Server error", error });
        }
}