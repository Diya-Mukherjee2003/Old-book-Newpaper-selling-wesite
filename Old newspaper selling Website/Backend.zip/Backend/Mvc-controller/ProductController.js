import { generateCookie } from "../utility/feature.js";
import { Product } from "../Model/productModel.js";
import bcrypt from 'bcrypt';

export const addProduct=async(req,res)=>{
    try{
        const {name, description, price, category, images}=req.body;
        const seller_id = req.user?._id; // Safe access to avoid errors
        if (!seller_id) {
            return res.status(401).json({ success: false, message: "Unauthorized: Please log in" });
        }
        const product=await Product.create({
            name, description, price, category, images,seller_id
        })
        res.status(200).json({
            success:true,
            message:'Product Added successfully',
            product
        })
    }catch(err){
        res.status(500).json({success:false,message:err.message})
    }    
}

export const updateProduct=async(req,res)=>{
    const product_id = req.params.id;
    try{
        const product=await Product.findById(product_id)
        if(!product){
            return res.status(400).json({
                success:false,
                message:'Product not Found'
            })
        }
        const updatedProduct=await Product.findByIdAndUpdate(product_id,req.body,{new:true})
        res.status(200).json({
            success:true,
            message:'Product updated successfully',
            product:updatedProduct
        })
    }catch (error) {
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
    
}

export const deleteProduct=async(req,res)=>{
    const product_id = req.params.id;
    try{
        const product=await Product.findByIdAndDelete(product_id)
        if(!product){
            return res.status(400).json({
                success:false,
                message:'Product not Found'
            })
        }
        await Product.findByIdAndDelete(product_id) 
        res.status(200).json({
            success:true,
            message:'Product deleted successfully',
        })
    }catch (error) {
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
    
}