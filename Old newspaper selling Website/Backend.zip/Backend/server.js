import express from 'express';
import mongoose from 'mongoose';
import cookieParser from 'cookie-parser';
import UserRouter from './Routes/userRoutes.js';
import ProductRouter from './Routes/productRoutes.js';
import OrderRouter from './Routes/orderRoutes.js';
import cors from 'cors';
import {config} from 'dotenv';

config({ path: './data/config.env' });

const app=express()
app.use(express.json())
app.use(cookieParser());

app.use(cors({
    origin: process.env.NODE_ENV, // Adjust based on your frontend URL
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization"]
}));





mongoose.connect(process.env.MONGO_URL,{
    dbName:"old-newspaper-selling-web",
}).then(()=>console.log("MongoDB is connected"))

app.use('/api/users/',UserRouter);
app.use('/api/products/',ProductRouter);
app.use('/api/orders/',OrderRouter);

const port =process.env.PORT

app.listen(port,()=>console.log(`Server is running on ${port}`))
