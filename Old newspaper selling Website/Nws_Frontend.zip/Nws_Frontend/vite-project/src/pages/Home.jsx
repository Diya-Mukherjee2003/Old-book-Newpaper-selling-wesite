import { useEffect, useState } from "react";
import NewspaperCard from "../components/NewspaperCard.jsx";


function Home() {
  const [products, setProducts] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/")
      .then((res) => res.text())
      .then((data) => setMessage(data))
      .catch((err) => {
        console.error("Error fetching data:", err);
        setMessage("Failed to load message from backend.");
      });

    setProducts([
      {
        id: 1,
        title: "The Times of India",
        date: "2023-10-01",
        description: "October edition, Mumbai city only."
      },
      {
        id: 2,
        title: "Hindustan Times",
        date: "2023-09-28",
        description: "Daily edition, Delhi NCR."
      },
      {
        id: 3,
        title: "The Telegraph",
        date: "2023-09-20",
        description: "Kolkata morning edition."
      }
    ]);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-t from-yellow-400 via-yellow-200 to-yellow-400 flex flex-col items-center space-y-8 py-10 px-6">
      <h1 className="text-4xl font-extrabold text-blue-600 text-center">Welcome to Old Newspaper Selling Website 🗞️</h1>
      <p className="text-lg text-gray-700">{message}</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 w-full">
        {products.map((newspaper) => (
          <NewspaperCard key={newspaper.id} newspaper={newspaper} />
        ))}
      </div>
    </div>
  );
}

export default Home;
