import React, { useEffect, useState } from "react";
import axios from "axios";

function NewsList() {
  const [newsList, setNewsList] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/api/news")
      .then((res) => setNewsList(res.data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div style={{ maxWidth: "600px", margin: "auto" }}>
      <h2>All News</h2>
      {newsList.length === 0 ? (
        <p>No news available.</p>
      ) : (
        newsList.map((news) => (
          <div key={news.id} style={{ border: "1px solid #ccc", margin: "10px 0", padding: "10px" }}>
            <h3>{news.title}</h3>
            <p>{news.content}</p>
            <small><b>Author:</b> {news.author}</small>
          </div>
        ))
      )}
    </div>
  );
}

export default NewsList;
