export default function About() {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold">About Us</h1>
        <p className="mt-2">We help you recycle newspapers and support eco-friendly living.</p>
      </div>
    );
  }
  