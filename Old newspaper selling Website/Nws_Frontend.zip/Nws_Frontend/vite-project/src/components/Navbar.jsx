import { Link } from "react-router-dom";
import {
  FaHome,
  FaInfoCircle,
  FaUserPlus,
  FaSignInAlt,
  FaPlus,
  FaNewspaper,
} from "react-icons/fa";

export default function Navbar() {
  return (
    <nav className="bg-gray-800 p-4 shadow-md">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Old Newspaper 🗞️</h1>
        <div className="right">
        <Link
              to="/"
              className="hover:text-yellow-400 flex items-center"
            >
              <FaHome className="mr-2" />
              Home
            </Link>

            <Link
              to="/about"
              className="hover:text-yellow-400 flex items-center"
            >
              <FaInfoCircle className="mr-2" />
              About
            </Link>

            <Link
              to="/register"
              className="hover:text-yellow-400 flex items-center"
            >
              <FaUserPlus className="mr-2" />
              Register
            </Link>

            <Link
              to="/login"
              className="hover:text-yellow-400 flex items-center"
            >
              <FaSignInAlt className="mr-2" />
              Login
            </Link>
            <Link
              to="/add-news"
              className="hover:text-yellow-400 flex items-center"
            >
              <FaPlus className="mr-2" />
              Add News
            </Link>
            <Link
              to="/news-list"
              className="hover:text-yellow-400 flex items-center"
            >
              <FaNewspaper className="mr-2" />
              View News
            </Link>

      </div>
        
      </div>
    </nav>
  );
}
