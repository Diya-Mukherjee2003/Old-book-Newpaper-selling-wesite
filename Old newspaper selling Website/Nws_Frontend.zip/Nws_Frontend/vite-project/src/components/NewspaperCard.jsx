export default function NewspaperCard({ newspaper }) {
  return (
    <div className="bg-white shadow-lg rounded-lg p-6 w-72 hover:shadow-xl transition duration-300">
      <h2 className="text-xl font-bold text-blue-600">{newspaper.title}</h2>
      <p className="text-sm text-gray-500">Published on: {newspaper.date}</p>
      <p className="text-gray-800 mt-3">{newspaper.description}</p>
    </div>
  );
}
