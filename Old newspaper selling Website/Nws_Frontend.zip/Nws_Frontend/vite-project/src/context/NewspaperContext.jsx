import { createContext, useState, useEffect } from "react";

export const NewspaperContext = createContext();

export const NewspaperProvider = ({ children }) => {
  const [newspapers, setNewspapers] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/newspapers")
      .then((res) => res.json())
      .then((data) => setNewspapers(data))
      .catch((err) => console.error("Error fetching data:", err));
  }, []);

  return (
    <NewspaperContext.Provider value={{ newspapers }}>
      {children}
    </NewspaperContext.Provider>
  );
};
